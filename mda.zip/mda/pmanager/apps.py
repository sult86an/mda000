from django.apps import AppConfig


class PmanagerConfig(AppConfig):
    name = 'pmanager'
