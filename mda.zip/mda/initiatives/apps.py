from django.apps import AppConfig


class InitiativesConfig(AppConfig):
    name = 'initiatives'
